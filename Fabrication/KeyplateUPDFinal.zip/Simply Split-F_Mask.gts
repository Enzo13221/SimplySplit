G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.6*
G04 #@! TF.CreationDate,2026-04-02T16:31:50-04:00*
G04 #@! TF.ProjectId,Simply Split,53696d70-6c79-4205-9370-6c69742e6b69,1*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.6) date 2026-04-02 16:31:50*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.200000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,H2*
X252695190Y-53768750D03*
G04 #@! TD*
G04 #@! TO.C,H4*
X272895190Y-53768750D03*
G04 #@! TD*
G04 #@! TO.C,H5*
X217695190Y-134068750D03*
G04 #@! TD*
G04 #@! TO.C,H3*
X232395190Y-110468750D03*
G04 #@! TD*
G04 #@! TO.C,H8*
X305795190Y-72668750D03*
G04 #@! TD*
G04 #@! TO.C,H1*
X198495190Y-120468750D03*
G04 #@! TD*
G04 #@! TO.C,H7*
X260695190Y-104068750D03*
G04 #@! TD*
M02*
